# ubuntu启动引导无windows

一般只需一句命令即可：

```bash
sudo update-grub
```

但如果出现这个警告：警告：Warning: os-prober will not be executed to detect other bootable partitions. Systems on them will not be added to the GRUB boot configuration. Check GRUB_DISABLE_OS_PROBER documentation entry. 这表示 os-prober 将不会被执行，因此在这些分区上的系统将不会被添加到 GRUB 引导配置中。
需要单独查看一下：

```bash
sudo os-prober
```

如果确实存在windows的话，只需编辑 /etc/default/grub 文件，找到 GRUB_DISABLE_OS_PROBER 这一行，如果它的值被设置为 true，那么就将它改为 false，然后再次运行 update-grub。

```bash
sudo vim /etc/default/grub
# 添加 GRUB_DISABLE_OS_PROBER=false
sudo update-grub
```
