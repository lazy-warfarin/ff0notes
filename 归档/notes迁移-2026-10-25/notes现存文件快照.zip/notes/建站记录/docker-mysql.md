# docker-mysql

docker mysql 相关
[原文链接](https://blog.csdn.net/u014282578/article/details/127920419)

1. 准备好mysql要映射的文件夹

```bash
mkdir -p /docker/mysql/log
mkdir -p /docker/mysql/data
mkdir -p /docker/mysql/conf
```

2. 创建配置

```bash
vim /docker/mysql/conf/custom.cnf
```

3. 编辑custome.cnf

```bash
[mysqld]
init-connect="SET collation_connection=utf8mb4_0900_ai_ci"
init_connect="SET NAMES utf8mb4"
```

4. 启动mysql

```bash
docker run --restart=always --name mysql -v /docker/mysql/log:/var/log/mysql -v /docker/mysql/data:/var/lib/mysql -v /docker/mysql/conf:/etc/mysql/conf.d -p 3306:3306 -e MYSQL_ROOT_PASSWORD=<REDACTED> -d mysql
```

(一次性完成(以mysql-test为例))

```bash
mkdir -p /docker/mysql-test/log
mkdir -p /docker/mysql-test/data
mkdir -p /docker/mysql-test/conf

echo "[mysqld]" > /docker/mysql/conf/custom.cnf
echo 'init-connect="SET collation_connection=utf8mb4_0900_ai_ci"' >> /docker/mysql/conf/custom.cnf
echo 'init_connect="SET NAMES utf8mb4"' >> /docker/mysql/conf/custom.cnf

docker run --restart=always --name mysql-test -v /docker/mysql-test/log:/var/log/mysql-test -v /docker/mysql-test/data:/var/lib/mysql-test -v /docker/mysql-test/conf:/etc/mysql-test/conf.d -p 33060:3306 -e MYSQL_ROOT_PASSWORD=<REDACTED> -d mysql

```
