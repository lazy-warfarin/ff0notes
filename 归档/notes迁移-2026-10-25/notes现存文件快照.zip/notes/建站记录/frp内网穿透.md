# frp内网穿透

[原文连接](https://blog.csdn.net/weixin_42265958/article/details/106008837)

- frp安装

```bash
# 自己去选择frp版本（目前0.57.0）
 wget https://github.com/fatedier/frp/releases/.........
 tar xzvf frp_0.15.1_linux_amd64.tar.gz
```

- Server frp设置

```frps.toml
bindPort = 7000

```

- Client frp设置

```frpc.toml
serverAddr = "154.40.47.134"
serverPort = 7000

[[proxies]]
name = "test-tcp"
type = "tcp"
localIP = "127.0.0.1"
localPort = 22
remotePort = 6000

```

- 远程frps启动

```bash
./frps -c ./frps.toml

# 以下是后台运行
nohup ./frps -c ./frps.toml > /dev/null 2>&1 &
# 想要终止进程的话，
# 先找到进程：
ps -aux|grep frp| grep -v grep
# 然后再杀掉进程即可：
kill -9 进程号
```

- 本地frpc启动（本地连接远程）

```bash
./frpc -c ./frpc.toml
```

- 远程登陆本地

```bash
# （mio@...）
ssh -p 6000 本地用户@远程ip
```

- 每次启动计算机时，frpc.exe 自动在后台运行：
打开 "运行" 对话框（按 Win + R），输入 shell:startup，然后按 Enter。这将打开 "启动" 文件夹。
将 start_frpc.bat 文件复制到 "启动" 文件夹中

start_frpc.bat：

```bat
@echo off
start /b frpc.exe绝对路径 -c frpc.toml绝对路径
```

一些注意点：

1. 一个客户端一个端口，~~配置好后frp会自己动~~，本地连远程时，远程会自动为本地连接分配端口（根据本地那个remotePort）

2. 远程服务器需要开启防火墙，哪个客户端连接就开哪个端口
3. 远程和本地都需要OpenSSH，记得下载和开启服务
4. 本地还需要准备一个远程登陆需要的用户，win可在控制面板中新建用户（默认用户不知道为啥密码一直不对）
