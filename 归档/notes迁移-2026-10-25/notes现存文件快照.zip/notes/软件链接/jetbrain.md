# jetbrain全家桶

[linux 2021.2到2024版本的激活工具](https://tvtyoma2gi.feishu.cn/docx/VHgEdoEu0oeFJ6xCfqKc23kLnme)
